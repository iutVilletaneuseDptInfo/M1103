import Cryptographie.cesar as cesar

def test_chiffre_cesar():
    assert cesar.chiffre_cesar("hello world!", 2) == "jgnnq yqtnf!"
    assert cesar.chiffre_cesar("HELLO WORLD!", 1) == "IFMMP XPSME!"
    assert cesar.chiffre_cesar("hello world!", 26) == "hello world!"
    assert cesar.chiffre_cesar("hello world!", 0) == "hello world!"
    assert cesar.chiffre_cesar("", 0) == ""
    assert cesar.chiffre_cesar("", 5) == ""
    print("test de la fonction chiffre_cesar : ok")



def test_dechiffre_cesar():
    assert cesar.dechiffre_cesar("jgnnq yqtnf!", 2) == "hello world!"
    assert cesar.dechiffre_cesar("ifmmp xpsme!", 1) == "hello world!"
    assert cesar.dechiffre_cesar("hello world!", 26) == "hello world!"
    assert cesar.dechiffre_cesar("hello world!", 0) == "hello world!"
    assert cesar.dechiffre_cesar("", 0) == ""
    assert cesar.dechiffre_cesar("", 5) == ""
    s = "Genial ! j'arrive a chiffrer et dechiffrer un message"
    assert cesar.dechiffre_cesar(cesar.chiffre_cesar(s, 17), 17) == s
    print("test de la fonction dechiffre_cesar : ok")



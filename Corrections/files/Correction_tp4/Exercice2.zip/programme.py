##################
#   Question 1   #
##################

# import Cryptographie.cesar as cesar

# print("Saisir le message à coder")
# texte = input()
# print("En clair :", texte)

# cle = 1
# while cle < 26:
#     print("Clé", cle, ":", cesar.chiffre_cesar(texte, cle))
#     cle += 1



##################
#   Question 3   #
##################


import Cryptographie.rot13 as rot13
print("Chiffrement ROT13 :", rot13.chiffre_ROT13("hello world"))
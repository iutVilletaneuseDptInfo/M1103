import Cryptographie.vigenere as vi

def test_chiffre_vigenere():

    assert vi.chiffre_vigenere("J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE.", "MUSIQUE") == "V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY."
    assert vi.chiffre_vigenere("J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE.", "musique") == "V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY."
    assert vi.chiffre_vigenere("J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE.".lower(), "MUSIQUE") == "V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY.".lower()


def test_dechiffre_vigenere():
    assert vi.dechiffre_vigenere("V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY.", "MUSIQUE") == "J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE."
    assert vi.dechiffre_vigenere("V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY.", "musique") == "J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE."
    assert vi.dechiffre_vigenere("V'UVWHY IOIMBUL PM LSLYI XAOLM BU NAOJVUY.".lower(), "MUSIQUE") == "J'ADORE ECOUTER LA RADIO TOUTE LA JOURNEE.".lower()

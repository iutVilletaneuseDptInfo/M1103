import Cryptographie.cesar as cesar


def chiffre_vigenere(s, cle):
    if cle == "":
        return s

    chiffrement = ""

    indiceCle = 0
    i = 0
    while i < len(s):
        # Si le ième caractère est une lettre (minuscule ou majuscule)
        if "a" <= s[i].lower() and s[i].lower() <= "z":
            if "a" <= s[i] and s[i] <= "z":
                chiffrement += cesar.chiffre_lettre(s[i], ord(cle[indiceCle].lower()) - ord("a"))
            else:
                chiffrement += cesar.chiffre_lettre(s[i], ord(cle[indiceCle].upper()) - ord("A"))
            indiceCle += 1
            if indiceCle == len(cle):
                indiceCle = 0
        else:
            chiffrement += s[i]
        i += 1

    return chiffrement


def dechiffre_vigenere(s, cle):
    if cle == "":
        return s

    chiffrement = ""

    indiceCle = 0
    i = 0
    while i < len(s):
        # Si le ième caractère est une lettre (minuscule ou majuscule)
        if "a" <= s[i].lower() and s[i].lower() <= "z":
            if "a" <= s[i] and s[i] <= "z":
                chiffrement += cesar.chiffre_lettre(s[i], - ord(cle[indiceCle].lower()) + ord("a"))
            else:
                chiffrement += cesar.chiffre_lettre(s[i], - ord(cle[indiceCle].upper()) + ord("A"))
            indiceCle += 1
            if indiceCle == len(cle):
                indiceCle = 0
        else:
            chiffrement += s[i]
        i += 1

    return chiffrement

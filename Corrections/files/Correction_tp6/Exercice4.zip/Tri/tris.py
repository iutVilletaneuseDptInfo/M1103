import Tri.utils as utils

def tri_selection(tab):
    """
        Trie le tableau passé en paramètre à l'aide du tri par sélection.
    """
    
    # définit la position au-delà de laquelle le tableau n'est
    # pas encore trié
    pos_debut_non_trie = 0
    while pos_debut_non_trie < len(tab) - 1:
        # recherche de la position du minimum à partir de pos_debut_non_trie
        i = pos_debut_non_trie
        pos_min = i
        while i < len(tab):
            if tab[i] < tab[pos_min]:
                pos_min = i
            i += 1
        # on place la valeur min à sa place à la fin de la partie déjà triée
        # en l'intervertissant avec la valeur de la première case non triée
        utils.swap_tab(tab, pos_debut_non_trie, pos_min)
        # on décale la position de debut de tableau non trié
        pos_debut_non_trie += 1


def tri_insertion(tab):
    """
        Trie le tableau passé en paramètre à l'aide du tri par insertion.
    """

    i = 1
    while i < len(tab):
        # Le tableau est trié de l'indice 0 à l'indice i-1.
        # On veut insérer l'élément tab[i] au bon endroit pour que le tableau soit trié
        # de l'indice 0 à l'indice i
        j = i
        while j >= 1 and tab[j] < tab[j - 1]:
            utils.swap_tab(tab, j - 1, j)
            j -= 1
        i += 1


def tri_bulle(tab):
    """
        Trie le tableau passé en paramètre à l'aide du tri à bulles.
    """

    # définit la longueur du tableau qui reste non triée
    longueur_non_triee = len(tab)
    while longueur_non_triee > 1:
        i = 0
        # on fait remonter les valeurs les plus grandes
        while i < longueur_non_triee - 1:
            if tab[i] > tab[i + 1]:
                utils.swap_tab(tab, i, i + 1)
            i += 1
        longueur_non_triee -= 1


def tri_comptage(tab):
    """
        Trie le tableau passé en paramètre à l'aide du tri par comptage.
    """

    if len(tab) == 0:
        return tab
    
    # recherche de la valeur min et max du tableau
    min = tab[0]
    max = tab[0]
    pos_non_trie = 0
    while pos_non_trie < len(tab):
        if tab[pos_non_trie] < min:
            min = tab[pos_non_trie]
        elif tab[pos_non_trie] > max:
            max = tab[pos_non_trie]
        pos_non_trie += 1
        
    # definition du tableau de comptage
    comptage = utils.tab_init(max - min + 1, 0)
    # comptage occurences de chaque valeur dans le tableau
    # a trier
    pos_non_trie = 0
    while pos_non_trie < len(tab):
        comptage[tab[pos_non_trie] - min] += 1
        pos_non_trie += 1
        
    # re-écriture du tableau trié
    pos_comptage = 0
    pos_non_trie = 0
    while pos_comptage < len(comptage):
        i = 0
        while i < comptage[pos_comptage]:
            tab[pos_non_trie] = min + pos_comptage
            pos_non_trie += 1
            i += 1
        pos_comptage += 1